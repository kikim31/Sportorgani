import { Pressable, ScrollView, StyleSheet, Text } from "react-native";

import { SPORTS, type Sport } from "@/lib/sportorg-data";
import { COLORS } from "@/components/sportorg/theme";

export function SportPills({ selected, onSelect }: { selected: Sport | null; onSelect: (sport: Sport | null) => void }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
      <Pill label="Tous" active={selected === null} onPress={() => onSelect(null)} />
      {SPORTS.map((sport) => (
        <Pill key={sport} label={sport} active={selected === sport} onPress={() => onSelect(sport)} />
      ))}
    </ScrollView>
  );
}

export function Pill({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" accessibilityState={{ selected: active }} onPress={onPress} style={({ pressed }) => [styles.pill, active && styles.active, pressed && styles.pressed]}>
      <Text style={[styles.label, active && styles.activeLabel]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { paddingHorizontal: 20, gap: 8 },
  pill: { minHeight: 38, justifyContent: "center", alignItems: "center", paddingHorizontal: 15, borderRadius: 14, backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.line },
  active: { backgroundColor: COLORS.navy, borderColor: COLORS.navy },
  label: { color: COLORS.navy, fontSize: 13, fontWeight: "700" },
  activeLabel: { color: COLORS.paper },
  pressed: { opacity: 0.78 },
});
