import { Image, StyleSheet, Text, View } from "react-native";

import { COLORS } from "@/components/sportorg/theme";

export function AppHeader({ eyebrow }: { eyebrow?: string }) {
  return (
    <View style={styles.row}>
      <Image source={require("../../assets/images/icon.png")} style={styles.logo} accessibilityLabel="Logo SportOrgani" />
      <View style={styles.brandText}>
        <Text style={styles.brandName}>
          Sport<Text style={styles.brandAccent}>Organi</Text>
        </Text>
        <Text style={styles.tagline}>{eyebrow ?? "TROUVEZ VOTRE ÉQUIPE"}</Text>
      </View>
      <View style={styles.demoBadge}>
        <Text style={styles.demoText}>DÉMO</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingTop: 8, paddingBottom: 18 },
  logo: { width: 44, height: 44, borderRadius: 14, marginRight: 12 },
  brandText: { flex: 1 },
  brandName: { color: COLORS.navy, fontSize: 21, fontWeight: "900", letterSpacing: -0.7 },
  brandAccent: { color: COLORS.greenDark },
  tagline: { color: COLORS.muted, fontSize: 9, fontWeight: "800", letterSpacing: 1.5, marginTop: 2 },
  demoBadge: { backgroundColor: COLORS.softOrange, paddingHorizontal: 9, paddingVertical: 5, borderRadius: 9 },
  demoText: { color: "#A85B12", fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
});
