import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { formatMatchDate, isMatchUpcoming, type SportMatch } from "@/lib/sportorg-data";
import { COLORS, SPORT_LABEL, SPORT_STYLE } from "@/components/sportorg/theme";

export function MatchCard({
  match,
  favorite,
  joined,
  organizer = false,
  onFavorite,
  onJoin,
}: {
  match: SportMatch;
  favorite: boolean;
  joined: boolean;
  organizer?: boolean;
  onFavorite: () => void;
  onJoin: () => void;
}) {
  const sportStyle = SPORT_STYLE[match.sport];
  const available = Math.max(0, match.maxPlayers - match.joinedPlayers);
  const full = available === 0;
  const upcoming = isMatchUpcoming(match);
  const actionLabel = organizer ? "Organisée par vous" : joined ? "Vous participez" : !upcoming ? "Terminé" : full ? "Complet" : "Rejoindre";

  return (
    <View style={styles.card}>
      <View style={styles.topLine}>
        <View style={[styles.sportIcon, { backgroundColor: sportStyle.soft }]}>
          <MaterialCommunityIcons name={sportStyle.icon} size={19} color={sportStyle.color} />
        </View>
        <View style={styles.sportTextWrap}>
          <Text style={[styles.sport, { color: sportStyle.color }]}>{SPORT_LABEL[match.sport].toUpperCase()}</Text>
          <Text style={styles.organizer}>Proposé par {match.organizer}</Text>
        </View>
        <Pressable accessibilityRole="button" accessibilityLabel={favorite ? "Retirer des favoris" : "Ajouter aux favoris"} onPress={onFavorite} hitSlop={10} style={({ pressed }) => [styles.favoriteButton, pressed && styles.pressed]}>
          <MaterialCommunityIcons name={favorite ? "heart" : "heart-outline"} size={22} color={favorite ? COLORS.red : COLORS.muted} />
        </Pressable>
      </View>

      <Text style={styles.title}>{match.title}</Text>

      <View style={styles.details}>
        <Detail icon="map-marker-outline" text={`${match.venue} · ${match.city}`} />
        <Detail icon="calendar-blank-outline" text={`${formatMatchDate(match.date)} · ${match.time}`} />
      </View>

      <View style={styles.footer}>
        <View style={styles.metaGroup}>
          <View style={styles.levelPill}><Text style={styles.levelText}>{match.level}</Text></View>
          <Text style={styles.price}>{match.price === 0 ? "Gratuit" : `${match.price} € / pers.`}</Text>
        </View>
        <View style={[styles.availability, full && styles.availabilityFull]}>
          <View style={[styles.dot, full && styles.dotFull]} />
          <Text style={[styles.availableText, (full || !upcoming) && styles.availableFull]}>{!upcoming ? "Terminé" : full ? "Complet" : `${available} place${available > 1 ? "s" : ""} libre${available > 1 ? "s" : ""}`}</Text>
        </View>
      </View>

      <Pressable
        accessibilityRole="button"
        accessibilityState={{ disabled: organizer || joined || full || !upcoming }}
        disabled={organizer || joined || full || !upcoming}
        onPress={onJoin}
        style={({ pressed }) => [styles.joinButton, (organizer || joined || full || !upcoming) && styles.joinDisabled, pressed && styles.pressed]}
      >
        <Text style={[styles.joinText, (organizer || joined || full || !upcoming) && styles.joinTextDisabled]}>{actionLabel}</Text>
        {!organizer && !joined && !full && upcoming ? <MaterialCommunityIcons name="arrow-right" size={18} color={COLORS.paper} /> : null}
      </Pressable>
      <Text style={styles.disclaimer}>Participation de démonstration · sans réservation ni paiement</Text>
    </View>
  );
}

function Detail({ icon, text }: { icon: "map-marker-outline" | "calendar-blank-outline"; text: string }) {
  return (
    <View style={styles.detailRow}>
      <MaterialCommunityIcons name={icon} size={17} color={COLORS.muted} />
      <Text numberOfLines={1} style={styles.detailText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: COLORS.paper, borderRadius: 22, padding: 16, borderWidth: 1, borderColor: COLORS.line, marginHorizontal: 20, marginBottom: 13 },
  topLine: { flexDirection: "row", alignItems: "center", marginBottom: 12 },
  sportIcon: { width: 38, height: 38, borderRadius: 13, justifyContent: "center", alignItems: "center", marginRight: 10 },
  sportTextWrap: { flex: 1 },
  sport: { fontSize: 10, letterSpacing: 1.2, fontWeight: "900" },
  organizer: { color: COLORS.muted, fontSize: 11, marginTop: 2 },
  favoriteButton: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 17, lineHeight: 22, fontWeight: "800", color: COLORS.navy, marginBottom: 10 },
  details: { gap: 7, marginBottom: 13 },
  detailRow: { flexDirection: "row", alignItems: "center", gap: 7 },
  detailText: { color: "#475267", fontSize: 12, flexShrink: 1 },
  footer: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: COLORS.line, paddingTop: 11, marginBottom: 12 },
  metaGroup: { flexDirection: "row", alignItems: "center", gap: 8 },
  levelPill: { backgroundColor: COLORS.cream, borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5 },
  levelText: { color: COLORS.navy, fontSize: 10, fontWeight: "700" },
  price: { color: COLORS.navy, fontSize: 12, fontWeight: "800" },
  availability: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: COLORS.softGreen, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 10 },
  availabilityFull: { backgroundColor: "#FCEDED" },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: COLORS.green },
  dotFull: { backgroundColor: COLORS.red },
  availableText: { color: COLORS.greenDark, fontSize: 10, fontWeight: "800" },
  availableFull: { color: COLORS.red },
  joinButton: { minHeight: 43, borderRadius: 13, backgroundColor: COLORS.green, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8 },
  joinDisabled: { backgroundColor: "#F0F1F2" },
  joinText: { color: COLORS.navy, fontSize: 13, fontWeight: "900" },
  joinTextDisabled: { color: COLORS.muted },
  disclaimer: { textAlign: "center", fontSize: 9, color: COLORS.muted, marginTop: 8 },
  pressed: { opacity: 0.72 },
});
