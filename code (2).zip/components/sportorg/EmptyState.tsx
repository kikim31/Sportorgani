import { MaterialCommunityIcons } from "@expo/vector-icons";
import { StyleSheet, Text, View } from "react-native";

import { COLORS } from "@/components/sportorg/theme";

export function EmptyState({ title, message }: { title: string; message: string }) {
  return (
    <View style={styles.container}>
      <View style={styles.iconWrap}><MaterialCommunityIcons name="whistle-outline" size={28} color={COLORS.greenDark} /></View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: "center", paddingHorizontal: 30, paddingTop: 32, paddingBottom: 28, marginHorizontal: 20, backgroundColor: COLORS.paper, borderRadius: 22, borderWidth: 1, borderColor: COLORS.line },
  iconWrap: { width: 58, height: 58, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.softGreen, marginBottom: 14 },
  title: { color: COLORS.navy, fontSize: 17, fontWeight: "800", textAlign: "center" },
  message: { color: COLORS.muted, fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 7 },
});
