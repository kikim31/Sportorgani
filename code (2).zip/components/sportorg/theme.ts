import type { Sport } from "@/lib/sportorg-data";

export const COLORS = {
  navy: "#101A30",
  green: "#18BF7B",
  greenDark: "#0A9460",
  cream: "#F6F4EC",
  paper: "#FFFFFF",
  orange: "#F28A24",
  blue: "#4183F4",
  muted: "#7B8495",
  line: "#E9E8E2",
  softGreen: "#E7F8F0",
  softOrange: "#FFF2E5",
  softBlue: "#EAF1FF",
  red: "#D75252",
};

export const SPORT_STYLE: Record<Sport, { icon: "soccer" | "basketball" | "tennis" | "tennis-ball"; color: string; soft: string }> = {
  Football: { icon: "soccer", color: COLORS.greenDark, soft: COLORS.softGreen },
  Basketball: { icon: "basketball", color: COLORS.orange, soft: COLORS.softOrange },
  Padel: { icon: "tennis", color: COLORS.blue, soft: COLORS.softBlue },
  Tennis: { icon: "tennis-ball", color: COLORS.navy, soft: "#EEF0F4" },
};

export const SPORT_LABEL: Record<Sport, string> = {
  Football: "Football",
  Basketball: "Basket",
  Padel: "Padel",
  Tennis: "Tennis",
};
