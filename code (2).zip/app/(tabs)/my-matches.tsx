import { MaterialCommunityIcons } from "@expo/vector-icons";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { AppHeader } from "@/components/sportorg/AppHeader";
import { EmptyState } from "@/components/sportorg/EmptyState";
import { MatchCard } from "@/components/sportorg/MatchCard";
import { COLORS } from "@/components/sportorg/theme";
import { useSportOrg } from "@/lib/sportorg-store";

export default function MyMatchesScreen() {
  const { matches, favoriteIds, joinedIds, createdIds, ready, toggleFavorite, joinMatch } = useSportOrg();
  const myMatches = matches.filter((match) => joinedIds.includes(match.id) || createdIds.includes(match.id));
  const createdCount = myMatches.filter((match) => createdIds.includes(match.id)).length;
  const joinedCount = myMatches.filter((match) => joinedIds.includes(match.id)).length;

  return (
    <SafeAreaView edges={["top"]} style={styles.safeArea}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <AppHeader eyebrow="TON AGENDA SPORTIF" />
        <View style={styles.hero}>
          <View style={styles.heroIcon}><MaterialCommunityIcons name="calendar-check" size={23} color={COLORS.green} /></View>
          <View style={styles.heroText}>
            <Text style={styles.title}>Mes matchs</Text>
            <Text style={styles.subtitle}>Ceux que tu rejoins et ceux que tu organises.</Text>
          </View>
        </View>
        <View style={styles.stats}>
          <Stat label="À jouer" value={joinedCount} icon="account-check-outline" />
          <View style={styles.statDivider} />
          <Stat label="Organisés" value={createdCount} icon="whistle-outline" />
        </View>
        {!ready ? <View style={styles.loading}><Text style={styles.loadingText}>Chargement de ton agenda…</Text></View> : myMatches.length ? myMatches.map((match) => (
          <View key={match.id}>
            <View style={styles.statusLabel}>
              <MaterialCommunityIcons name={createdIds.includes(match.id) ? "star-circle" : "check-circle"} size={15} color={createdIds.includes(match.id) ? COLORS.orange : COLORS.greenDark} />
              <Text style={styles.statusText}>{createdIds.includes(match.id) ? "Organisé par toi" : "Tu participes"}</Text>
            </View>
            <MatchCard
              match={match}
              favorite={favoriteIds.includes(match.id)}
              joined={joinedIds.includes(match.id)}
              organizer={createdIds.includes(match.id)}
              onFavorite={() => toggleFavorite(match.id)}
              onJoin={() => joinMatch(match.id)}
            />
          </View>
        )) : <EmptyState title="Ton agenda est libre" message="Rejoins un match ou crée ta propre partie : elle apparaîtra ici." />}
        <View style={styles.disclaimer}>
          <MaterialCommunityIcons name="information-outline" size={15} color={COLORS.muted} />
          <Text style={styles.disclaimerText}>Agenda de démonstration sur cet appareil — aucune réservation confirmée.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Stat({ label, value, icon }: { label: string; value: number; icon: "account-check-outline" | "whistle-outline" }) {
  return (
    <View style={styles.stat}>
      <MaterialCommunityIcons name={icon} size={18} color={COLORS.greenDark} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.cream },
  content: { paddingBottom: 28 },
  hero: { marginHorizontal: 20, backgroundColor: COLORS.navy, borderRadius: 22, padding: 18, flexDirection: "row", alignItems: "center" },
  heroIcon: { width: 48, height: 48, borderRadius: 16, backgroundColor: "#1E2B47", alignItems: "center", justifyContent: "center", marginRight: 13 },
  heroText: { flex: 1 },
  title: { color: COLORS.paper, fontSize: 23, fontWeight: "900" },
  subtitle: { color: "#C5CDDB", fontSize: 11, lineHeight: 16, marginTop: 4 },
  stats: { marginHorizontal: 20, marginTop: 14, marginBottom: 19, backgroundColor: COLORS.paper, borderRadius: 18, borderWidth: 1, borderColor: COLORS.line, flexDirection: "row", alignItems: "center", justifyContent: "space-evenly", paddingVertical: 13 },
  stat: { flexDirection: "row", alignItems: "center", gap: 7 },
  statValue: { color: COLORS.navy, fontSize: 17, fontWeight: "900" },
  statLabel: { color: COLORS.muted, fontSize: 11, fontWeight: "700" },
  statDivider: { width: 1, height: 28, backgroundColor: COLORS.line },
  statusLabel: { marginHorizontal: 25, marginBottom: 6, flexDirection: "row", alignItems: "center", gap: 5 },
  statusText: { color: COLORS.muted, fontSize: 10, fontWeight: "800" },
  loading: { padding: 28, alignItems: "center" },
  loadingText: { color: COLORS.muted },
  disclaimer: { marginTop: 3, marginHorizontal: 22, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  disclaimerText: { fontSize: 10, color: COLORS.muted, textAlign: "center" },
});
