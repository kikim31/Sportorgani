import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Platform, StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { COLORS } from "@/components/sportorg/theme";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 9 : Math.max(insets.bottom, 7);
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarActiveTintColor: COLORS.greenDark,
        tabBarInactiveTintColor: COLORS.muted,
        tabBarStyle: [styles.tabBar, { height: 59 + bottomPadding, paddingBottom: bottomPadding }],
        tabBarLabelStyle: styles.label,
        tabBarItemStyle: styles.item,
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Explorer", tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="compass-outline" size={size ?? 21} color={color} /> }} />
      <Tabs.Screen name="favorites" options={{ title: "Favoris", tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="heart-outline" size={size ?? 21} color={color} /> }} />
      <Tabs.Screen name="my-matches" options={{ title: "Mes matchs", tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="calendar-check-outline" size={size ?? 21} color={color} /> }} />
      <Tabs.Screen name="create" options={{ title: "Créer", tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="plus-circle-outline" size={size ?? 21} color={color} /> }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: { backgroundColor: COLORS.paper, borderTopColor: COLORS.line, borderTopWidth: 1, paddingTop: 5 },
  item: { paddingTop: 1 },
  label: { fontSize: 9, fontWeight: "800", marginTop: -1 },
});
