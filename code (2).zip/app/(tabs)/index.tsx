import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { AppHeader } from "@/components/sportorg/AppHeader";
import { EmptyState } from "@/components/sportorg/EmptyState";
import { MatchCard } from "@/components/sportorg/MatchCard";
import { Pill, SportPills } from "@/components/sportorg/SportPills";
import { COLORS } from "@/components/sportorg/theme";
import { isMatchUpcoming, type Sport } from "@/lib/sportorg-data";
import { useSportOrg } from "@/lib/sportorg-store";

export default function ExploreScreen() {
  const { matches, favoriteIds, joinedIds, ready, toggleFavorite, joinMatch } = useSportOrg();
  const [selectedSport, setSelectedSport] = useState<Sport | null>(null);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const cities = useMemo(() => [...new Set(matches.map((match) => match.city))].sort((a, b) => a.localeCompare(b, "fr")), [matches]);
  const filteredMatches = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase("fr");
    return matches.filter((match) => {
      if (!isMatchUpcoming(match)) return false;
      const matchesSport = !selectedSport || match.sport === selectedSport;
      const matchesCity = !selectedCity || match.city === selectedCity;
      const searchable = `${match.title} ${match.sport} ${match.venue} ${match.city} ${match.level}`.toLocaleLowerCase("fr");
      return matchesSport && matchesCity && (!normalizedQuery || searchable.includes(normalizedQuery));
    });
  }, [matches, query, selectedCity, selectedSport]);

  return (
    <SafeAreaView edges={["top"]} style={styles.safeArea}>
      <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <AppHeader eyebrow="TROUVEZ VOTRE ÉQUIPE" />
        <View style={styles.hero}>
          <View style={styles.heroTextWrap}>
            <Text style={styles.kicker}>LE SPORT À PLUSIEURS</Text>
            <Text style={styles.title}>Ton prochain match{ "\n" }commence ici.</Text>
            <Text style={styles.subtitle}>Trouve des joueurs près de toi et rejoins la partie.</Text>
          </View>
          <View style={styles.heroBall}><MaterialCommunityIcons name="soccer" size={32} color={COLORS.green} /></View>
        </View>

        <View style={styles.searchBox}>
          <MaterialCommunityIcons name="magnify" size={22} color={COLORS.muted} />
          <TextInput
            accessibilityLabel="Rechercher un sport, un lieu ou une ville"
            value={query}
            onChangeText={setQuery}
            placeholder="Sport, lieu ou ville…"
            placeholderTextColor="#9AA1AE"
            returnKeyType="search"
            style={styles.searchInput}
          />
          {query.length > 0 ? <Pressable accessibilityRole="button" accessibilityLabel="Effacer la recherche" onPress={() => setQuery("")}><MaterialCommunityIcons name="close-circle" size={19} color={COLORS.muted} /></Pressable> : null}
        </View>

        <View style={styles.sectionHeading}>
          <Text style={styles.sectionTitle}>Quel sport ?</Text>
          <Text style={styles.resultCount}>{filteredMatches.length} match{filteredMatches.length > 1 ? "s" : ""}</Text>
        </View>
        <SportPills selected={selectedSport} onSelect={setSelectedSport} />

        <View style={[styles.sectionHeading, styles.cityHeading]}>
          <Text style={styles.sectionTitle}>Autour de quelle ville ?</Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.cityPills}>
          <Pill label="Toutes" active={selectedCity === null} onPress={() => setSelectedCity(null)} />
          {cities.map((city) => <Pill key={city} label={city} active={selectedCity === city} onPress={() => setSelectedCity(city)} />)}
        </ScrollView>

        <View style={[styles.sectionHeading, styles.matchesHeading]}>
          <View>
            <Text style={styles.sectionTitle}>Les matchs à rejoindre</Text>
            <Text style={styles.sectionCaption}>Des parties proposées par la communauté</Text>
          </View>
          <MaterialCommunityIcons name="arrow-down" size={18} color={COLORS.muted} />
        </View>

        {!ready ? <View style={styles.loading}><Text style={styles.loadingText}>Préparation des matchs…</Text></View> : filteredMatches.length ? filteredMatches.map((match) => (
          <MatchCard
            key={match.id}
            match={match}
            favorite={favoriteIds.includes(match.id)}
            joined={joinedIds.includes(match.id)}
            onFavorite={() => toggleFavorite(match.id)}
            onJoin={() => joinMatch(match.id)}
          />
        )) : <EmptyState title="Aucun match trouvé" message="Essaie une autre ville, un autre sport ou une recherche plus courte." />}

        <View style={styles.localNote}>
          <MaterialCommunityIcons name="information-outline" size={15} color={COLORS.muted} />
          <Text style={styles.localNoteText}>Données de démonstration locales · aucune réservation confirmée.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.cream },
  scrollContent: { paddingBottom: 24 },
  hero: { marginHorizontal: 20, marginBottom: 18, padding: 19, borderRadius: 24, backgroundColor: COLORS.navy, minHeight: 155, flexDirection: "row", alignItems: "center", overflow: "hidden" },
  heroTextWrap: { flex: 1, paddingRight: 6 },
  kicker: { color: COLORS.green, fontSize: 9, letterSpacing: 1.5, fontWeight: "900", marginBottom: 7 },
  title: { color: COLORS.paper, fontSize: 24, lineHeight: 28, fontWeight: "900", letterSpacing: -0.5 },
  subtitle: { color: "#C5CDDB", fontSize: 12, lineHeight: 17, marginTop: 7, maxWidth: 245 },
  heroBall: { width: 63, height: 63, borderRadius: 24, backgroundColor: "#1E2B47", alignItems: "center", justifyContent: "center", marginLeft: 3 },
  searchBox: { minHeight: 51, marginHorizontal: 20, marginBottom: 19, backgroundColor: COLORS.paper, borderRadius: 15, borderWidth: 1, borderColor: COLORS.line, flexDirection: "row", alignItems: "center", paddingHorizontal: 13, gap: 9 },
  searchInput: { flex: 1, color: COLORS.navy, fontSize: 14, minHeight: 48, paddingVertical: 0 },
  sectionHeading: { marginHorizontal: 20, marginBottom: 10, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sectionTitle: { color: COLORS.navy, fontSize: 16, fontWeight: "900" },
  resultCount: { color: COLORS.muted, fontSize: 11, fontWeight: "700" },
  cityHeading: { marginTop: 19 },
  cityPills: { paddingHorizontal: 20, gap: 8 },
  matchesHeading: { marginTop: 24, marginBottom: 12 },
  sectionCaption: { color: COLORS.muted, fontSize: 11, marginTop: 3 },
  loading: { marginHorizontal: 20, padding: 30, alignItems: "center" },
  loadingText: { color: COLORS.muted, fontSize: 13 },
  localNote: { marginHorizontal: 22, marginTop: 3, marginBottom: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  localNoteText: { color: COLORS.muted, fontSize: 10, textAlign: "center" },
});
