import { MaterialCommunityIcons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { AppHeader } from "@/components/sportorg/AppHeader";
import { Pill } from "@/components/sportorg/SportPills";
import { COLORS, SPORT_STYLE } from "@/components/sportorg/theme";
import { SPORTS, type MatchLevel, type Sport } from "@/lib/sportorg-data";
import { useSportOrg } from "@/lib/sportorg-store";

const LEVELS: MatchLevel[] = ["Débutant", "Intermédiaire", "Avancé"];

function dateInDays(days: number) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()}`;
}

function toIsoDate(value: string) {
  const [day, month, year] = value.split("/");
  return `${year}-${month}-${day}`;
}

export default function CreateMatchScreen() {
  const { createMatch, ready } = useSportOrg();
  const [sport, setSport] = useState<Sport>("Football");
  const [venue, setVenue] = useState("");
  const [city, setCity] = useState("");
  const [date, setDate] = useState(dateInDays(2));
  const [time, setTime] = useState("18:30");
  const [level, setLevel] = useState<MatchLevel>("Intermédiaire");
  const [places, setPlaces] = useState(10);
  const [price, setPrice] = useState("5");
  const [error, setError] = useState("");

  const submit = () => {
    if (!ready) return;
    const dateIsFormatted = /^\d{2}\/\d{2}\/\d{4}$/.test(date.trim());
    const dateParts = date.trim().split("/").map(Number);
    const day = dateParts[0] ?? 0;
    const month = dateParts[1] ?? 0;
    const year = dateParts[2] ?? 0;
    const timeParts = time.trim().split(":").map(Number);
    const hours = timeParts[0] ?? 0;
    const minutes = timeParts[1] ?? 0;
    const validTime = /^([01]\d|2[0-3]):[0-5]\d$/.test(time.trim());
    const candidateDate = new Date(year, month - 1, day, hours, minutes);
    const validDate = dateIsFormatted && year >= 2025 && candidateDate.getFullYear() === year && candidateDate.getMonth() === month - 1 && candidateDate.getDate() === day;
    const parsedPrice = Number(price.replace(",", "."));
    if (!venue.trim() || !city.trim()) {
      setError("Indique le lieu et la ville du match.");
      return;
    }
    if (!validDate || !validTime) {
      setError("Vérifie la date (JJ/MM/AAAA) et l’heure (HH:MM).");
      return;
    }
    if (candidateDate.getTime() <= Date.now()) {
      setError("Choisis une date et une heure dans le futur.");
      return;
    }
    if (!Number.isFinite(parsedPrice) || parsedPrice < 0) {
      setError("Le prix indicatif doit être un nombre positif ou égal à zéro.");
      return;
    }

    createMatch({
      sport,
      title: `${sport === "Basketball" ? "Basket" : sport} entre joueurs`,
      venue: venue.trim(),
      city: city.trim(),
      date: toIsoDate(date.trim()),
      time: time.trim(),
      level,
      price: parsedPrice,
      maxPlayers: places,
      organizer: "Vous",
    });
    setError("");
    router.replace("/(tabs)/my-matches");
  };

  return (
    <SafeAreaView edges={["top"]} style={styles.safeArea}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
          <AppHeader eyebrow="ORGANISE TA PARTIE" />
          <View style={styles.heading}>
            <Text style={styles.title}>Crée ton match</Text>
            <Text style={styles.subtitle}>Quelques détails, et l’équipe peut se retrouver.</Text>
          </View>

          <View style={styles.formCard}>
            <FieldTitle number="01" title="Choisis un sport" />
            <View style={styles.sportGrid}>
              {SPORTS.map((item) => {
                const selected = item === sport;
                const sportStyle = SPORT_STYLE[item];
                return (
                  <Pressable key={item} accessibilityRole="button" accessibilityState={{ selected }} onPress={() => setSport(item)} style={[styles.sportOption, selected && styles.sportOptionSelected]}>
                    <View style={[styles.sportIcon, { backgroundColor: selected ? COLORS.green : sportStyle.soft }]}>
                      <MaterialCommunityIcons name={sportStyle.icon} size={18} color={selected ? COLORS.navy : sportStyle.color} />
                    </View>
                    <Text style={[styles.sportLabel, selected && styles.sportLabelSelected]}>{item === "Basketball" ? "Basket" : item}</Text>
                  </Pressable>
                );
              })}
            </View>

            <FieldTitle number="02" title="Où se retrouve-t-on ?" top />
            <TextInput value={venue} onChangeText={setVenue} placeholder="Nom du terrain ou du lieu" placeholderTextColor="#9AA1AE" style={styles.input} returnKeyType="next" />
            <TextInput value={city} onChangeText={setCity} placeholder="Ville (ex. Lyon)" placeholderTextColor="#9AA1AE" style={[styles.input, styles.secondInput]} returnKeyType="next" />

            <FieldTitle number="03" title="Quand ?" top />
            <View style={styles.inlineFields}>
              <View style={styles.fieldHalf}>
                <Text style={styles.label}>Date</Text>
                <View style={styles.inputWithIcon}>
                  <MaterialCommunityIcons name="calendar-blank-outline" size={17} color={COLORS.muted} />
                  <TextInput value={date} onChangeText={setDate} placeholder="JJ/MM/AAAA" placeholderTextColor="#9AA1AE" style={styles.inlineInput} keyboardType="numbers-and-punctuation" maxLength={10} />
                </View>
              </View>
              <View style={styles.fieldHalf}>
                <Text style={styles.label}>Heure</Text>
                <View style={styles.inputWithIcon}>
                  <MaterialCommunityIcons name="clock-outline" size={17} color={COLORS.muted} />
                  <TextInput value={time} onChangeText={setTime} placeholder="18:30" placeholderTextColor="#9AA1AE" style={styles.inlineInput} keyboardType="numbers-and-punctuation" maxLength={5} />
                </View>
              </View>
            </View>

            <FieldTitle number="04" title="Pour quel niveau ?" top />
            <View style={styles.levelRow}>
              {LEVELS.map((item) => <Pill key={item} label={item} active={level === item} onPress={() => setLevel(item)} />)}
            </View>

            <FieldTitle number="05" title="Places et prix indicatif" top />
            <View style={styles.inlineFields}>
              <View style={styles.fieldHalf}>
                <Text style={styles.label}>Nombre de places</Text>
                <View style={styles.stepper}>
                  <Pressable accessibilityRole="button" accessibilityLabel="Retirer une place" onPress={() => setPlaces((value) => Math.max(2, value - 1))} style={styles.stepButton}><MaterialCommunityIcons name="minus" size={17} color={COLORS.navy} /></Pressable>
                  <Text style={styles.stepValue}>{places}</Text>
                  <Pressable accessibilityRole="button" accessibilityLabel="Ajouter une place" onPress={() => setPlaces((value) => Math.min(22, value + 1))} style={styles.stepButton}><MaterialCommunityIcons name="plus" size={17} color={COLORS.navy} /></Pressable>
                </View>
              </View>
              <View style={styles.fieldHalf}>
                <Text style={styles.label}>Prix / joueur</Text>
                <View style={styles.priceInput}>
                  <TextInput value={price} onChangeText={setPrice} placeholder="0" placeholderTextColor="#9AA1AE" style={styles.priceTextInput} keyboardType="decimal-pad" maxLength={6} />
                  <Text style={styles.euro}>€</Text>
                </View>
              </View>
            </View>
            <Text style={styles.helper}>Le prix est indicatif : aucun paiement n’est demandé dans cette démo.</Text>
          </View>

          {error ? <View style={styles.errorBox}><MaterialCommunityIcons name="alert-circle-outline" size={17} color={COLORS.red} /><Text style={styles.errorText}>{error}</Text></View> : null}
          <Pressable accessibilityRole="button" disabled={!ready} onPress={submit} style={({ pressed }) => [styles.submit, !ready && styles.submitDisabled, pressed && styles.pressed]}>
            <MaterialCommunityIcons name="plus-circle-outline" size={20} color={COLORS.navy} />
            <Text style={styles.submitText}>{ready ? "Publier le match" : "Préparation…"}</Text>
            <MaterialCommunityIcons name="arrow-right" size={18} color={COLORS.navy} />
          </Pressable>
          <Text style={styles.localNote}>Création locale de démonstration · aucune réservation confirmée.</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function FieldTitle({ number, title, top = false }: { number: string; title: string; top?: boolean }) {
  return (
    <View style={[styles.fieldTitleRow, top && styles.fieldTitleTop]}>
      <Text style={styles.fieldNumber}>{number}</Text>
      <Text style={styles.fieldTitle}>{title}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  safeArea: { flex: 1, backgroundColor: COLORS.cream },
  content: { paddingBottom: 26 },
  heading: { marginHorizontal: 20, marginBottom: 16 },
  title: { color: COLORS.navy, fontSize: 24, fontWeight: "900", letterSpacing: -0.5 },
  subtitle: { color: COLORS.muted, fontSize: 12, marginTop: 4 },
  formCard: { marginHorizontal: 20, padding: 16, backgroundColor: COLORS.paper, borderRadius: 22, borderWidth: 1, borderColor: COLORS.line },
  fieldTitleRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  fieldTitleTop: { marginTop: 21 },
  fieldNumber: { color: COLORS.greenDark, backgroundColor: COLORS.softGreen, overflow: "hidden", borderRadius: 8, paddingHorizontal: 7, paddingVertical: 4, fontSize: 9, fontWeight: "900" },
  fieldTitle: { color: COLORS.navy, fontSize: 14, fontWeight: "800" },
  sportGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 11 },
  sportOption: { flexGrow: 1, minWidth: "46%", flexDirection: "row", alignItems: "center", gap: 8, padding: 9, borderRadius: 13, borderWidth: 1, borderColor: COLORS.line, backgroundColor: COLORS.paper },
  sportOptionSelected: { borderColor: COLORS.green, backgroundColor: "#F0FBF6" },
  sportIcon: { width: 32, height: 32, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  sportLabel: { color: COLORS.navy, fontSize: 12, fontWeight: "700" },
  sportLabelSelected: { fontWeight: "900" },
  input: { minHeight: 46, marginTop: 11, borderWidth: 1, borderColor: COLORS.line, borderRadius: 12, paddingHorizontal: 12, color: COLORS.navy, fontSize: 13, backgroundColor: "#FCFCFA" },
  secondInput: { marginTop: 8 },
  inlineFields: { flexDirection: "row", gap: 9, marginTop: 11 },
  fieldHalf: { flex: 1 },
  label: { color: COLORS.muted, fontSize: 10, fontWeight: "800", marginBottom: 6 },
  inputWithIcon: { height: 46, borderWidth: 1, borderColor: COLORS.line, borderRadius: 12, flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 9, backgroundColor: "#FCFCFA" },
  inlineInput: { flex: 1, minWidth: 0, color: COLORS.navy, fontSize: 12, paddingVertical: 0 },
  levelRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 11 },
  stepper: { height: 46, flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderWidth: 1, borderColor: COLORS.line, borderRadius: 12, paddingHorizontal: 5, backgroundColor: "#FCFCFA" },
  stepButton: { width: 34, height: 34, backgroundColor: COLORS.softGreen, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  stepValue: { color: COLORS.navy, fontWeight: "900", fontSize: 15 },
  priceInput: { height: 46, borderWidth: 1, borderColor: COLORS.line, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 12, backgroundColor: "#FCFCFA" },
  priceTextInput: { flex: 1, color: COLORS.navy, fontWeight: "800", fontSize: 14, paddingVertical: 0 },
  euro: { color: COLORS.muted, fontWeight: "800", fontSize: 13 },
  helper: { color: COLORS.muted, fontSize: 10, lineHeight: 15, marginTop: 8 },
  errorBox: { marginTop: 12, marginHorizontal: 20, flexDirection: "row", alignItems: "center", gap: 7, borderRadius: 12, backgroundColor: "#FCEDED", padding: 11 },
  errorText: { flex: 1, color: COLORS.red, fontSize: 12, fontWeight: "700" },
  submit: { minHeight: 52, marginTop: 14, marginHorizontal: 20, borderRadius: 15, backgroundColor: COLORS.green, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9 },
  submitDisabled: { opacity: 0.5 },
  submitText: { color: COLORS.navy, fontSize: 14, fontWeight: "900" },
  pressed: { opacity: 0.75 },
  localNote: { textAlign: "center", color: COLORS.muted, fontSize: 10, marginHorizontal: 24, marginTop: 9 },
});
