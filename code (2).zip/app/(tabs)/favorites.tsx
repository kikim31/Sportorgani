import { MaterialCommunityIcons } from "@expo/vector-icons";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { AppHeader } from "@/components/sportorg/AppHeader";
import { EmptyState } from "@/components/sportorg/EmptyState";
import { MatchCard } from "@/components/sportorg/MatchCard";
import { COLORS } from "@/components/sportorg/theme";
import { useSportOrg } from "@/lib/sportorg-store";

export default function FavoritesScreen() {
  const { matches, favoriteIds, joinedIds, ready, toggleFavorite, joinMatch } = useSportOrg();
  const favorites = matches.filter((match) => favoriteIds.includes(match.id));

  return (
    <SafeAreaView edges={["top"]} style={styles.safeArea}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <AppHeader eyebrow="TES MATCHS REPÉRÉS" />
        <View style={styles.headingRow}>
          <View style={styles.iconWrap}><MaterialCommunityIcons name="heart" size={21} color={COLORS.red} /></View>
          <View style={styles.headingText}>
            <Text style={styles.title}>Mes favoris</Text>
            <Text style={styles.subtitle}>Garde les bons matchs sous la main.</Text>
          </View>
          <Text style={styles.count}>{favorites.length}</Text>
        </View>
        {!ready ? <View style={styles.loading}><Text style={styles.loadingText}>Chargement des favoris…</Text></View> : favorites.length ? favorites.map((match) => (
          <MatchCard
            key={match.id}
            match={match}
            favorite
            joined={joinedIds.includes(match.id)}
            onFavorite={() => toggleFavorite(match.id)}
            onJoin={() => joinMatch(match.id)}
          />
        )) : <EmptyState title="Rien dans tes favoris" message="Appuie sur le cœur d’un match qui te tente pour le retrouver ici." />}
        <View style={styles.localNote}>
          <MaterialCommunityIcons name="cellphone-check" size={16} color={COLORS.greenDark} />
          <Text style={styles.localNoteText}>Tes favoris sont enregistrés localement sur cet appareil.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.cream },
  content: { paddingBottom: 28 },
  headingRow: { flexDirection: "row", alignItems: "center", marginHorizontal: 20, marginTop: 4, marginBottom: 20 },
  iconWrap: { width: 46, height: 46, borderRadius: 16, backgroundColor: "#FCEDED", justifyContent: "center", alignItems: "center", marginRight: 12 },
  headingText: { flex: 1 },
  title: { color: COLORS.navy, fontSize: 23, fontWeight: "900", letterSpacing: -0.5 },
  subtitle: { color: COLORS.muted, fontSize: 12, marginTop: 3 },
  count: { color: COLORS.greenDark, fontSize: 14, fontWeight: "900", backgroundColor: COLORS.softGreen, borderRadius: 12, overflow: "hidden", paddingHorizontal: 10, paddingVertical: 6 },
  loading: { padding: 28, alignItems: "center" },
  loadingText: { color: COLORS.muted },
  localNote: { marginTop: 8, marginHorizontal: 22, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6 },
  localNoteText: { color: COLORS.muted, fontSize: 10 },
});
