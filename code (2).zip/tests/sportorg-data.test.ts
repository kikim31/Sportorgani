import { describe, expect, it } from "vitest";

import { formatMatchDate, isMatchUpcoming } from "../lib/sportorg-data";

const isoDateAfter = (days: number) => {
  const date = new Date();
  date.setDate(date.getDate() + days);
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
};

describe("SportOrgani demo match dates", () => {
  it("formats today's date in French", () => {
    expect(formatMatchDate(isoDateAfter(0))).toBe("Aujourd’hui");
  });

  it("keeps a future match available and marks a past match as expired", () => {
    expect(isMatchUpcoming({ date: isoDateAfter(2), time: "23:59" })).toBe(true);
    expect(isMatchUpcoming({ date: "2000-01-01", time: "12:00" })).toBe(false);
  });

  it("rejects malformed local date-time values", () => {
    expect(isMatchUpcoming({ date: "not-a-date", time: "18:30" })).toBe(false);
    expect(isMatchUpcoming({ date: isoDateAfter(2), time: "not-a-time" })).toBe(false);
  });
});
