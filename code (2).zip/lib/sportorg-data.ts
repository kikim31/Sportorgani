export const SPORTS = ["Football", "Basketball", "Padel", "Tennis"] as const;

export type Sport = (typeof SPORTS)[number];
export type MatchLevel = "Débutant" | "Intermédiaire" | "Avancé";

export type SportMatch = {
  id: string;
  sport: Sport;
  title: string;
  venue: string;
  city: string;
  date: string;
  time: string;
  level: MatchLevel;
  price: number;
  maxPlayers: number;
  joinedPlayers: number;
  organizer: string;
};

const dateAfter = (days: number) => {
  const date = new Date();
  date.setDate(date.getDate() + days);
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
};

export const createDemoMatches = (): SportMatch[] => [
  {
    id: "demo-foot-lyon",
    sport: "Football",
    title: "Foot à 5 — rythme cool",
    venue: "UrbanSoccer Lyon",
    city: "Lyon",
    date: dateAfter(0),
    time: "18:30",
    level: "Intermédiaire",
    price: 6,
    maxPlayers: 10,
    joinedPlayers: 7,
    organizer: "Nabil",
  },
  {
    id: "demo-basket-paris",
    sport: "Basketball",
    title: "Basket 3×3 en fin de journée",
    venue: "Playground République",
    city: "Paris",
    date: dateAfter(1),
    time: "19:00",
    level: "Débutant",
    price: 0,
    maxPlayers: 8,
    joinedPlayers: 5,
    organizer: "Camille",
  },
  {
    id: "demo-padel-bordeaux",
    sport: "Padel",
    title: "Double mixte — bonne ambiance",
    venue: "Bordeaux Padel Campus",
    city: "Bordeaux",
    date: dateAfter(2),
    time: "17:30",
    level: "Intermédiaire",
    price: 9,
    maxPlayers: 4,
    joinedPlayers: 2,
    organizer: "Inès",
  },
  {
    id: "demo-tennis-marseille",
    sport: "Tennis",
    title: "Échange tranquille sur terre battue",
    venue: "Tennis Club Borély",
    city: "Marseille",
    date: dateAfter(1),
    time: "10:00",
    level: "Débutant",
    price: 5,
    maxPlayers: 2,
    joinedPlayers: 1,
    organizer: "Yanis",
  },
  {
    id: "demo-foot-paris",
    sport: "Football",
    title: "Match à 7 — niveau confirmé",
    venue: "Le Five Paris 18",
    city: "Paris",
    date: dateAfter(3),
    time: "20:15",
    level: "Avancé",
    price: 8,
    maxPlayers: 14,
    joinedPlayers: 10,
    organizer: "Mehdi",
  },
  {
    id: "demo-padel-lyon",
    sport: "Padel",
    title: "Padel du dimanche",
    venue: "Esprit Padel Lyon",
    city: "Lyon",
    date: dateAfter(4),
    time: "11:00",
    level: "Débutant",
    price: 7,
    maxPlayers: 4,
    joinedPlayers: 3,
    organizer: "Sarah",
  },
  {
    id: "demo-basket-nantes",
    sport: "Basketball",
    title: "Pick-up basket — tous niveaux",
    venue: "Gymnase Mangin-Beaulieu",
    city: "Nantes",
    date: dateAfter(2),
    time: "16:00",
    level: "Intermédiaire",
    price: 3,
    maxPlayers: 10,
    joinedPlayers: 6,
    organizer: "Louis",
  },
  {
    id: "demo-tennis-bordeaux",
    sport: "Tennis",
    title: "Simple du samedi matin",
    venue: "Villa Primrose",
    city: "Bordeaux",
    date: dateAfter(5),
    time: "09:30",
    level: "Avancé",
    price: 6,
    maxPlayers: 2,
    joinedPlayers: 1,
    organizer: "Émile",
  },
];

export const formatMatchDate = (value: string) => {
  const matchDate = new Date(`${value}T12:00:00`);
  if (Number.isNaN(matchDate.getTime())) return value;
  const today = new Date();
  const targetDay = new Date(matchDate.getFullYear(), matchDate.getMonth(), matchDate.getDate());
  const todayDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const difference = Math.round((targetDay.getTime() - todayDay.getTime()) / 86_400_000);
  if (difference === 0) return "Aujourd’hui";
  if (difference === 1) return "Demain";
  return new Intl.DateTimeFormat("fr-FR", { weekday: "short", day: "numeric", month: "short" })
    .format(matchDate)
    .replace(".", "");
};

export const isMatchUpcoming = (match: Pick<SportMatch, "date" | "time">) => {
  const eventDate = new Date(`${match.date}T${match.time}:00`);
  return !Number.isNaN(eventDate.getTime()) && eventDate.getTime() > Date.now();
};
