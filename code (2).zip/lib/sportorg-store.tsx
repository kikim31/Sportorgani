import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

import { createDemoMatches, isMatchUpcoming, type SportMatch } from "@/lib/sportorg-data";

const STORAGE_KEY = "sportorgani-demo-v1";

type StoredState = {
  matches: SportMatch[];
  favoriteIds: string[];
  joinedIds: string[];
  createdIds: string[];
};

type SportOrgContextValue = StoredState & {
  ready: boolean;
  toggleFavorite: (id: string) => void;
  joinMatch: (id: string) => boolean;
  createMatch: (match: Omit<SportMatch, "id" | "joinedPlayers">) => string;
};

const SportOrgContext = createContext<SportOrgContextValue | null>(null);

export function SportOrgProvider({ children }: { children: React.ReactNode }) {
  const [matches, setMatches] = useState<SportMatch[]>(createDemoMatches);
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [joinedIds, setJoinedIds] = useState<string[]>([]);
  const [createdIds, setCreatedIds] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!active || !raw) return;
        try {
          const parsed = JSON.parse(raw) as Partial<StoredState>;
          if (Array.isArray(parsed.matches)) setMatches(parsed.matches as SportMatch[]);
          if (Array.isArray(parsed.favoriteIds)) setFavoriteIds(parsed.favoriteIds as string[]);
          if (Array.isArray(parsed.joinedIds)) setJoinedIds(parsed.joinedIds as string[]);
          if (Array.isArray(parsed.createdIds)) setCreatedIds(parsed.createdIds as string[]);
        } catch {
          // A malformed local demo cache is ignored; the seeded fixtures remain usable.
        }
      })
      .catch(() => {
        // The app remains fully usable with in-memory fixtures when device storage is unavailable.
      })
      .finally(() => {
        if (active) setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const state: StoredState = { matches, favoriteIds, joinedIds, createdIds };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => undefined);
  }, [matches, favoriteIds, joinedIds, createdIds, ready]);

  const toggleFavorite = useCallback((id: string) => {
    setFavoriteIds((current) =>
      current.includes(id) ? current.filter((favoriteId) => favoriteId !== id) : [...current, id],
    );
  }, []);

  const joinMatch = useCallback(
    (id: string) => {
      if (!ready) return false;
      if (joinedIds.includes(id)) return false;
      const match = matches.find((item) => item.id === id);
      if (!match || !isMatchUpcoming(match) || match.joinedPlayers >= match.maxPlayers) return false;
      setMatches((current) =>
        current.map((item) =>
          item.id === id && item.joinedPlayers < item.maxPlayers
            ? { ...item, joinedPlayers: item.joinedPlayers + 1 }
            : item,
        ),
      );
      setJoinedIds((current) => (current.includes(id) ? current : [...current, id]));
      return true;
    },
    [joinedIds, matches, ready],
  );

  const createMatch = useCallback((match: Omit<SportMatch, "id" | "joinedPlayers">) => {
    if (!ready) return "";
    const id = `local-${Date.now()}`;
    const newMatch: SportMatch = { ...match, id, joinedPlayers: 0 };
    setMatches((current) => [newMatch, ...current]);
    setCreatedIds((current) => [id, ...current]);
    return id;
  }, [ready]);

  const value = useMemo(
    () => ({ matches, favoriteIds, joinedIds, createdIds, ready, toggleFavorite, joinMatch, createMatch }),
    [matches, favoriteIds, joinedIds, createdIds, ready, toggleFavorite, joinMatch, createMatch],
  );

  return <SportOrgContext.Provider value={value}>{children}</SportOrgContext.Provider>;
}

export function useSportOrg() {
  const context = useContext(SportOrgContext);
  if (!context) throw new Error("useSportOrg must be used inside SportOrgProvider");
  return context;
}
